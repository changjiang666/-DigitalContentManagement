$(document).ready(function () {
    fetchData();
});

function fetchData() {
    $.ajax({
        url:  "ServletDemo",
        dataType:"json",
        type : "post",
        data: {
            "op": "3",
        },
        success: function (data) {
            var parent = $("#stuTable tbody");
            parent.html("");
            var tableHead = `
               <tr id="tablehead">
                <th>
                    <input type="checkbox" id="allcheckbox" value="option1" aria-label="..." onclick="allSelect()">
                </th>
            
                <th>文件名</th>
                <th>标签</th>
                <th>文件类型</th>
                <th>时间日期</th>
                <th>操作</th>
            </tr>
            `;

            parent.append(tableHead);
            $.each(data, function (index, value) {
                var item = `
            <tr id=${value.id} value=${value.url}>
                <td>
                    <input type="checkbox" class="acheckbox" value="option1" aria-label="..." data-id=${value.id}>
                </td>
                <td>${value.name}</td>
                <td>${value.label}</td>
                <td>${value.suffix}</td>
                <td>${value.time}</td>
                <td>
                    <input type="hidden" name="opBrief" />
                    <a class="update"  data-toggle="modal" data-target="#open"  data-id=${value.id} onclick="openItem(this)">打开</a>|
                    <a class="update"  data-toggle="modal" data-target="#update"  data-id=${value.id} onclick="modifyItem(this)">修改</a> |
                    <a  class="delete" data-id=${value.id} onclick="deleteItem(this)">删除</a>
                </td>
            </tr>
            `;
                parent.append(item);
            });
        }
    })
}
function addItem() {
    var name = $("#inputname").val();
    name=name.substring(name.lastIndexOf("\\") + 1);
    var url = document.getElementById("inputname").files[0];
    var fileurl = URL.createObjectURL(url);
    var stuId =  $("#inputnumber").val();
    var major = "";
    var obj = document.getElementsByName("Type");
     // console.log(name);
    var tagname;
    for(var i=0; i<obj.length; i ++){
        if(obj[i].checked){
           major = obj[i].value;
        }
    }
     var date = $("#inputdate").val();
     console.log(name, stuId, major, date);

    if (!(name || stuId || major || major || date)){
        alert("请填写完整学生信息");
    } else {
        $.ajax({
            url: "ServletDemo",
            type : "post",
            data: {
                "op": "1",
                "addname": name,
                "addstudentid": stuId,
                "addmajor": major,
                "addtime": date,
                "addurl": fileurl
            },
            success: function () {

				$("#inputname").val("");
				$("#inputnumber").val("");
				$("#inputgen").val("");
				$("#inputdate").val("");
                fetchData();
            }
        })
        //console.log(name, stuId, major, date);
    }
}
function deleteItem(item) {
    if (confirm("确定删除吗？")) {
        var id = $(item).attr("data-id")
        $.ajax({
            url: "ServletDemo",
            type : "post",
            dataType:"json",
            data: {
                "op": "4",
                "id": id
            },
            success: function () {
                fetchData();
            },
            complete:function () {
                fetchData();
            }
        })
        console.log("delete:",id);
        // $(this).parents("tr").fadeOut(300);
    }
}
function modifyItem(item) {
    var id = $(item).attr("data-id")
    var name = $(item).parent().parent().children().eq(1).text();
    var number = $(item).parent().parent().children().eq(2).text();
    var gen = $(item).parent().parent().children().eq(3).text();
    var date = $(item).parent().parent().children().eq(4).text();
    $("#inputname2").val(name);
    $("#inputnumber2").val(number);
    $("#inputgen2").val(gen);
    $("#inputdate2").val(date);
    $("#save").click(function () {
        name = $("#inputname2").val();
        number = $("#inputnumber2").val();
        gen = $("#inputgen2").val();
        date = $("#inputdate2").val();
        $.ajax({
            url: "ServletDemo",
            type : "post",
            dataType:"json",
            data: {
                "op": "6",
                "id": id,
                "updatename": name,
                "updatestudentid": number,
                "updatemajor": gen,
                "updatetime": date,
            },
            success: function () {
                fetchData();
            },
            complete:function(){
                fetchData();
            }
        })
    })
}
function searchStu() {
    var name = $("#name-search").val();
    var major = $("#major-search").val();
    if (!(name || major)) {
        alert("请输入文件名或者标签");
        return false;
    } else {
        $.ajax({
            url: "ServletDemo",
            dataType:"json",
            type : "post",
            data: {
                "op": "2",
                "name": name,
                "major": major,
            },
            success: function (data) {
                var parent = $("#stuTable tbody");
                parent.html("");
                var tableHead = `
               <tr id="tablehead">
                <th>
                    <input type="checkbox" id="allcheckbox" value="option1" aria-label="..." onclick="allSelect()">
                </th>
                <th>文件名</th>
                <th>标签</th>
                <th>文件类型</th>
                <th>时间日期</th>
                <th>操作</th>
            </tr>
            `
                parent.append(tableHead);
                $.each(data, function (index, value) {
                    var item = `
            <tr id=${value.id}>
                <td>
                    <input type="checkbox" class="acheckbox" value="option1" aria-label="..." data-id=${value.id}>
                </td>
                <td>${value.name}</td>
                <td>${value.label}</td>
                <td>${value.suffix}</td>
                <td>${value.time}</td>
                <td>
                    <input type="hidden" name="opBrief" />
                    <a class="update"  data-toggle="modal" data-target="#open"  data-id=${value.id} onclick="">打开</a> |
                    <a class="update"  data-toggle="modal" data-target="#update"  data-id=${value.id} onclick="modifyItem(this)">修改</a> |
                    <a  class="delete" data-id=${value.id} onclick="deleteItem(this)">删除</a>
                </td>
            </tr>
            `;
                    parent.append(item);
                });
            }
        })
        console.log(name, major);
    }

}
function deleteMultiSelected() {
    var cb = $("input[type=checkbox]:checked");
    if (cb.length == 0) {
        alert("至少选择一条");
    } else if (confirm("确定删除吗？")) {
        var selectedItem = [];
        for (var i = 0; i < cb.length; i++) {
            if ($(cb[i]).attr("data-id")) {
                selectedItem.push($(cb[i]).attr("data-id"))
            }
        }
        $.ajax({
            url: "ServletDemo",
            dataType:"json",
            type : "post",
            data: {
                "op": "5",
                "id": selectedItem.join(",")
            },
            success: function () {
                fetchData();
            },
            complete:function () {
                fetchData();
            }
        })
        console.log(selectedItem);
    }
}
var flag = false;
function allSelect() {
    var cb = $("input[type=checkbox]")
    for (var i = 0; i < cb.length; i++) {
        cb[i].checked = flag;
    }
    flag = !flag
}
function openItem(item){
    var url = $(item).parent().parent().attr("value");
    // url.value
    console.log(url);
    // console.log(URL.revokeObjectURL(url));
    // url.getElementsByName()
    // URL.createObjectURL(url)
    // document.getElementById("audio_id").src = URL.revokeObjectURL(url);
    $("#audio_id").attr("src", url);
}
