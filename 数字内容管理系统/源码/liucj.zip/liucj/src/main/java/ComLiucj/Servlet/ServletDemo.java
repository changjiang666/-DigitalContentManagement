package ComLiucj.Servlet;
import ComLiucj.Model.Files;
import ComLiucj.service.Service;
import net.sf.json.JSONArray;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
@WebServlet("/ComLiucj.Servlet.ServletDemo")
public class ServletDemo extends HttpServlet {
    public ServletDemo() {
        super();
    }
    public void init() throws ServletException {
        // Put your code here
    }

    public void destroy() {
        super.destroy(); // Just puts "destroy" string in log
        // Put your code here
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String op = request.getParameter("op");
//        System.out.println("后台获取的操作参数"+op);
        if(op.equals("1") ){//添加学生
            String name = request.getParameter("addname");
            String label= request.getParameter("addstudentid");
            String suffix = request.getParameter("addmajor");
            String time = request.getParameter("addtime");
            String url = request.getParameter("addurl");
            Files stu = new Files();
            stu.setUrl(url);
            stu.setName(name);
            stu.setLabel(label);
            stu.setSuffix(suffix);
            stu.setTime(time);
            Service s = Service.getInstance();
            s.insertStudent(stu);
//            System.out.println("servlet添加完成");
//            response.sendRedirect("index.jsp");
        }else if(op.equals("2") ){//查找学生
            String name = request.getParameter("name");
            String major = request.getParameter("major");
//            System.out.println("查找学生");
//            System.out.println("前台获取的参数"+name);
//            System.out.println("前台获取的参数"+major);
            Service s = Service.getInstance();
            List<Files> list = null;
            if(name.equals("")&&(!major.equals(""))){
//                System.out.println("专业不为空");

                list = s.findByMajor(major);
            }else if(!name.equals("")&&major.equals("")){
//                System.out.println("名字不为空");
                list = s.findByName(name);
            }else{
//                System.out.println("参数都不为空");
                list = s.findBoth(name,major);
            }
//            System.out.println(list);
            JSONArray jsonArray2 = JSONArray.fromObject(list);
            response.setCharacterEncoding("utf-8");
            //写入到前台
            response.getWriter().write(jsonArray2.toString());
//            System.out.println("servlet查找完成");
//            response.sendRedirect("index.jsp");
        }else if(op.equals("3") ){
//            System.out.println("初始化查找所有学生");
            Service s = Service.getInstance();
            List<Files> list = s.findAll();
            JSONArray jsonArray2 = JSONArray.fromObject( list );
            response.setCharacterEncoding("utf-8");
            //写入到前台
            response.getWriter().write(jsonArray2.toString());
//            response.sendRedirect("index.jsp");
        }else if(op.equals("4") ){//删除一个学生
//            System.out.println("删除");
            String id = request.getParameter("id");
//            System.out.println(id);
            int b = Integer.valueOf(id).intValue();
//            System.out.println("删除的id"+b);
            Service s = Service.getInstance();
            s.deleteStudent(b);
//            System.out.println("删除完毕");

        }else if(op.equals("5") ){//删除多个学生
            String idlist = request.getParameter("id");
//            System.out.println("获得的参数"+idlist);
            String[] arr = idlist.split("\\,");
            List<Integer> dellist = new ArrayList<Integer>();
            for (String x:arr
            ) {
                int b = Integer.valueOf(x).intValue();
                dellist.add(b);
            }
            Service s = Service.getInstance();
            s.deleteBatch(dellist);
        }else if(op.equals("6") ){//更新学生信息
//            System.out.println("更新学生信息");
            String id = request.getParameter("id");
            String name = request.getParameter("updatename");
            String label = request.getParameter("updatestudentid");
            String suffix = request.getParameter("updatemajor");
            String time = request.getParameter("updatetime");
//            System.out.println("学生信息"+id+name+studentid+major+time);
            Service s = Service.getInstance();
            int intid= Integer.valueOf(id).intValue();
            Files stu = s.findById(intid);
            stu.setName(name);
            stu.setLabel(label);
            stu.setSuffix(suffix);
            stu.setTime(time);
            s.updateStudent(stu);
//            System.out.println("更新学生信息完毕");

        }

    }
}
