package ComLiucj.Dao;

import ComLiucj.Dao_interface.Dao_interface;
import ComLiucj.Model.Files;
import ComLiucj.Utility.Utility;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class Dao {
    //声明实例变量
    private static Dao daoinstance;
    //获取AminDao实例
    public static final Dao getInstance(){
        if(daoinstance == null) {
            try {
                daoinstance = new Dao();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return daoinstance;
    }

    /**
     * 查询所有文件
     * @return List<Files>
     */
    public List<Files> findAll()
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        List<Files> list = stuMapper.findAll();
        sqlSession.close();
        return list;
    }


    /**
     * 综合查询
     */
    public List<Files> findBoth(String name, String label)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        List<Files> list = stuMapper.findBoth(name,label);
        sqlSession.close();//此处人为关闭，不知有没有影响
        return list;
    }

    /**
     * 按照文件名查询
     */
    public List<Files> findByName(String name)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        List<Files> list = stuMapper.findByName(name);
        sqlSession.close();//此处人为关闭，不知有没有影响
        return list;
    }

    /**
     * 按照标签查找
     */
    public  List<Files>  findByLabel(String label)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        List<Files> list = stuMapper.findByLabel(label);
        sqlSession.close();//此处人为关闭，不知有没有影响
        return list;
    }

    public Files findById(int id)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        Files li = stuMapper.findById(id);
        sqlSession.close();//此处人为关闭，不知有没有影响
        return li;
    }


    /**
     * 添加一个文件名
     * @param file
     */
    public void insertFile(Files file)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        stuMapper.insertFile(file);
        sqlSession.commit();
        sqlSession.close();
    }


    /**
     * 删除一个学生
     * @param id
     */
    public void deleteFile(int id)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        Files stu = stuMapper.findById(id);
        sqlSession.delete("deleteFile", stu);
        sqlSession.commit();
        sqlSession.close();
    }

    /**
     * 批量删除
     * @param ids
     * @return
     */
    public int deleteBatch(List<Integer> ids)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        Dao_interface stuMapper = sqlSession.getMapper(Dao_interface.class);
        int total = stuMapper.deleteBatch(ids);
        sqlSession.commit();
        sqlSession.close();
        return total;
    }

    /**
     * 修改学生信息
     * @param file
     */
    public void updateFile(Files file)
    {
        SqlSession sqlSession = Utility.getSessionFactory().openSession();
        sqlSession.update("updateStudent", file);
        sqlSession.commit();
        sqlSession.close();

    }
}
