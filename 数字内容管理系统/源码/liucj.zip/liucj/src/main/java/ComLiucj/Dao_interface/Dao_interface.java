package ComLiucj.Dao_interface;

import ComLiucj.Model.Files;
import java.util.List;

public interface Dao_interface
{
    /**
     * 查询所有文件
     * @return List<Files>
     */
    public List<Files> findAll();

    /**
     * 综合查询
     */
    public List<Files> findBoth(String name, String label);

    /**
     * 按照文件名查询
     */
    public List<Files> findByName(String name);

    /**
     * 按照标签查找
     */
    public  List<Files>  findByLabel(String label);

    public Files findById(int id);

    /**
     * 添加一个文件名
     * @param file
     */
    public void insertFile(Files file);

    /**
     * 删除一个学生
     * @param id
     */
    public void deleteFile(int id);

    /**
     * 批量删除
     * @param ids
     * @return
     */
    public int deleteBatch(List<Integer> ids);

    /**
     * 修改学生信息
     * @param file
     */
    public void updateFile(Files file);
}
