package ComLiucj.service;

import ComLiucj.Dao.Dao;
import ComLiucj.Model.Files;

import java.util.List;

public class Service {
    private Dao dao;
    private static Service instance;

    public Service() {
        dao = Dao.getInstance();
    }


    /**
     * 获取实例
     *
     * @return
     */
    public static final Service getInstance() {
        if (instance == null) {
            try {
                instance = new Service();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return instance;
    }
    /**
     * 查询所有文件
     * @return List<Student>
     */
    public List<Files> findAll(){
        return dao.findAll();
    }


    /**
     * 按照名字查找;
     * @param name
     * @return List<Student>
     */
    public List<Files> findByName(String name){
        return dao.findByName(name);
    }

    public List<Files> findBoth(String name,String label){
        return dao.findBoth(name,label);
    }



    /**
     * 按照标签查找;
     * @param label
     * @return List<Student>
     */
    public  List<Files>  findByMajor(String label){
        return dao.findByLabel(label);
    }


    public Files findById(int id){
        return dao.findById(id);
    }

    /**
     * 添加一个文件
     * @param file
     */
    public void insertStudent(Files file){
        dao.insertFile(file);
    }

    /**
     * 删除一个文件
     * @param id
     */
    public void deleteStudent(int id){
        dao.deleteFile(id);
    }

    /**
     * 批量删除
     * @param ids
     * @return
     */
    public int deleteBatch(List<Integer> ids){
        return dao.deleteBatch(ids);
    }

    /**
     * 修改文件信息
     * @param file
     */
    public void updateStudent(Files file){
        dao.updateFile(file);
    }

}
