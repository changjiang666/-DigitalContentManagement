import ComLiucj.service.Service;

public class Test {
    public static void main(String[] args){
        Service s = Service.getInstance();
        System.out.println(s.findAll());
    }
}
